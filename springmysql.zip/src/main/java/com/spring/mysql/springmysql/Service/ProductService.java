package com.spring.mysql.springmysql.Service;

import com.spring.mysql.springmysql.Entity.Product;
import com.spring.mysql.springmysql.Repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public Product saveProduct(Product product){
        return productRepository.save(product);
    }

    
    public List<Product> getProductsAll(){
        return productRepository.findAll();
    }



}
